## utils/aiptw_estimator.R
## Pure-function AIPTW survival estimator for the discrete-time / logit-PLR
## formulation (Bang & Robins 2005; Funk et al. 2011; Kurz 2022; Gabriel et
## al. 2024). Designed to be called many times from a replication driver and
## from a bootstrap loop without any top-level side effects.
##
## Inputs:
##   surv.df      one row per individual; must contain columns
##                  id, eventtime, event, A, L1..L6, L1sq, L2sq, W, O
##   ps_spec      RHS string for the propensity model, e.g. "L1 + L2 + ... + W"
##   out_spec     RHS string for the discrete-time hazard model, e.g.
##                  "A + L1 + L1sq + L2 + L2sq + L3 + L4 + L5 + L6 + O + W"
##   t_eval       vector of evaluation time points (default 1, 5, 10)
##   admin.cens   administrative censoring boundary (default 10)
##   rescale_time discrete-time interval width (default 1/4)
##   ps_trim      P(A|L) clipping range (default c(0.01, 0.99))
##
## Returns: data.frame with columns t, S0, S1, RD on RAW scale (no clipping).
##
## Notes:
##   - IPW does NOT enter the outcome PLR; it enters only via the augmentation.
##   - Logit link is required for the AIPTW algebraic equivalence (Gabriel
##     et al. 2024); cloglog would break double-robustness.
##   - IPCW uses the left-limit G(t-) and >= so that admin-censored survivors
##     at t = admin.cens are correctly retained.
##   - Returns NA on any internal error, so a bootstrap loop can keep going.

aiptw_estimate <- function(surv.df,
                            ps_spec,
                            out_spec,
                            t_eval        = c(1, 5, 10),
                            admin.cens    = 10,
                            rescale_time  = 1/4,
                            ps_trim       = c(0.01, 0.99)) {

  tryCatch({

    interval_ends <- seq(rescale_time, admin.cens, by = rescale_time)
    split_cuts    <- interval_ends[-length(interval_ends)]
    interval_mapping <- data.frame(
      time_period = seq_along(interval_ends),
      time        = interval_ends
    )

    # Long-format (person-period). Use unqualified Surv(...) on the LHS:
    # survSplit() parses the formula's LHS by looking for an unqualified
    # `Surv` call. Writing `survival::Surv(...)` on the LHS triggers
    # `Error: left hand side not recognized`. The caller must therefore
    # have library(survival) attached -- the driver and demo scripts do.
    surv.long.df <- survival::survSplit(
      Surv(eventtime, event) ~ .,
      data    = surv.df,
      cut     = split_cuts,
      episode = "time_period"
    )

    baseline.covs <- dplyr::select(
      surv.df, id, L1, L1sq, L2, L2sq, L3, L4, L5, L6, O, W
    )

    # Censoring KM at left limit G(t-). Same Surv() unqualified-LHS rule.
    cens.km <- survival::survfit(
      Surv(eventtime, 1L - event) ~ 1, data = surv.df
    )
    G_tminus <- summary(
      cens.km, times = pmax(t_eval - 1e-8, 0), extend = TRUE
    )$surv
    G_tminus <- pmax(G_tminus, 1e-6)

    # Propensity score model
    ps.mod <- stats::glm(
      stats::as.formula(paste("A ~", ps_spec)),
      family = "binomial", data = surv.df
    )
    pi_1 <- pmin(pmax(stats::predict(ps.mod, type = "response"),
                      ps_trim[1]), ps_trim[2])

    # Unstabilised indicator weights for the augmentation term
    ipw_ind1 <- ifelse(surv.df$A == 1L, 1 / pi_1,       0)
    ipw_ind0 <- ifelse(surv.df$A == 0L, 1 / (1 - pi_1), 0)

    # Outcome model: unweighted PLR with canonical logit link
    plr.formula <- stats::as.formula(
      paste0("event ~ ", out_spec, " + as.factor(time_period)")
    )
    plr.mod <- stats::glm(
      plr.formula, data = surv.long.df,
      family = stats::binomial(link = "logit")
    )

    # Counterfactual prediction grid. Hot path -- built with rep() and
    # base R matrix ops rather than expand.grid / dplyr left_join /
    # group_by / cumprod, because this code runs once per replicate and
    # once per bootstrap. For a 2500-patient dataset with 40 time
    # periods this previously dominated the per-fit cost (200k-row
    # data frames, sorted joins, 5,000-group cumprod). The matrix
    # version is roughly an order of magnitude faster.
    n_periods <- length(interval_ends)
    N         <- nrow(surv.df)

    bc_rep <- baseline.covs[rep(seq_len(N), n_periods), , drop = FALSE]
    bc_rep$time_period <- rep(seq_len(n_periods), each = N)
    bc_rep$event       <- 0L

    bc_rep$A   <- 0L
    haz0_vec   <- stats::predict(plr.mod, newdata = bc_rep, type = "response")
    bc_rep$A   <- 1L
    haz1_vec   <- stats::predict(plr.mod, newdata = bc_rep, type = "response")

    # Reshape to N x n_periods. Column k = hazard at time-period k.
    H0 <- matrix(haz0_vec, nrow = N, ncol = n_periods)
    H1 <- matrix(haz1_vec, nrow = N, ncol = n_periods)

    # Row-wise cumulative survival: S(k) = prod_{j<=k} (1 - H[, j]).
    S0_mat <- matrix(NA_real_, nrow = N, ncol = n_periods)
    S1_mat <- matrix(NA_real_, nrow = N, ncol = n_periods)
    S0_mat[, 1] <- 1 - H0[, 1]
    S1_mat[, 1] <- 1 - H1[, 1]
    if (n_periods > 1L) {
      for (k in 2:n_periods) {
        S0_mat[, k] <- S0_mat[, k - 1] * (1 - H0[, k])
        S1_mat[, k] <- S1_mat[, k - 1] * (1 - H1[, k])
      }
    }

    obs_time <- surv.df$eventtime

    out <- lapply(seq_along(t_eval), function(k) {
      t <- t_eval[k]
      if (t == 0) return(data.frame(t = 0, S0 = 1, S1 = 1, RD = 0))

      tp <- interval_mapping$time_period[
        max(which(interval_mapping$time <= t))
      ]

      Q0 <- S0_mat[, tp]
      Q1 <- S1_mat[, tp]

      Y_ipcw <- as.numeric(obs_time >= t) / G_tminus[k]

      S0 <- mean(Q0 + ipw_ind0 * (Y_ipcw - Q0))
      S1 <- mean(Q1 + ipw_ind1 * (Y_ipcw - Q1))
      data.frame(t = t, S0 = S0, S1 = S1, RD = S1 - S0)
    })

    out_df <- do.call(rbind, out)
    out_df$status    <- "ok"
    out_df$error_msg <- NA_character_
    out_df

  }, error = function(e) {
    # Surface the failure to the caller instead of silently returning NA.
    # The replication driver and aggregator both inspect $status so a
    # scenario's success rate can be reported separately from n_reps.
    data.frame(
      t         = t_eval,
      S0        = NA_real_,
      S1        = NA_real_,
      RD        = NA_real_,
      status    = "error",
      error_msg = conditionMessage(e),
      stringsAsFactors = FALSE
    )
  })
}


## Bootstrap wrapper -- non-parametric individual-level resampling.
##
## Returns a data.frame with one row per (t, target) and columns
##   t, target, se, ci_lo, ci_hi   (target in {"S0", "S1", "RD"})

aiptw_bootstrap <- function(surv.df, ps_spec, out_spec,
                             t_eval       = c(1, 5, 10),
                             admin.cens   = 10,
                             rescale_time = 1/4,
                             ps_trim      = c(0.01, 0.99),
                             B            = 200,
                             ci_level     = 0.95) {

  stopifnot(is.numeric(B), length(B) == 1L, B >= 0L)
  N <- nrow(surv.df)
  alpha <- (1 - ci_level) / 2

  # B = 0 fast path: skip resampling and emit NA SE / CIs directly. Used
  # by smoke tests that want point estimates only. Without this guard the
  # downstream do.call(rbind, list()) returns NULL and group_by() errors.
  if (B == 0L) {
    return(data.frame(
      t             = rep(t_eval, 3),
      target        = rep(c("S0", "S1", "RD"), each = length(t_eval)),
      n_boot_total  = 0L,
      n_boot_ok     = 0L,
      n_boot_failed = 0L,
      se            = NA_real_,
      ci_lo         = NA_real_,
      ci_hi         = NA_real_,
      boot_errors   = NA_character_,
      stringsAsFactors = FALSE
    ))
  }

  # Each bootstrap returns a (length(t_eval) x 3) data frame; stack into
  # a long table keyed by (b, t, target).
  boot_long  <- vector("list", B)
  boot_errs  <- character(0)            # collect distinct error messages
  for (b in seq_len(B)) {
    idx     <- sample.int(N, N, replace = TRUE)
    boot.df <- surv.df[idx, ]
    boot.df$id <- seq_len(N)            # re-id so survSplit etc. behave
    est <- aiptw_estimate(boot.df, ps_spec, out_spec, t_eval,
                          admin.cens, rescale_time, ps_trim)
    if (any(est$status == "error")) {
      msg <- est$error_msg[1]
      if (!is.na(msg) && !msg %in% boot_errs) boot_errs <- c(boot_errs, msg)
    }
    boot_long[[b]] <- data.frame(
      b      = b,
      t      = rep(est$t, 3),
      target = rep(c("S0", "S1", "RD"), each = nrow(est)),
      val    = c(est$S0, est$S1, est$RD)
    )
  }
  boot_long_df <- do.call(rbind, boot_long)
  boot_err_str <- if (length(boot_errs) == 0L) NA_character_ else
                   paste(boot_errs, collapse = " | ")

  # Guard against empty / single-value bootstrap distributions:
  #   - sd() on < 2 non-NA values returns NA with a warning.
  #   - quantile() on 0 non-NA values warns "no non-missing arguments"; in
  #     some R versions and with type = 7 (default) it can also error.
  # Compute SE / CIs only when the underlying sample has enough non-NA
  # values, otherwise emit NA explicitly. n_boot_failed is always
  # available to audit the cause.
  safe_sd <- function(v) {
    if (sum(!is.na(v)) < 2L) NA_real_ else stats::sd(v, na.rm = TRUE)
  }
  safe_q  <- function(v, p) {
    if (sum(!is.na(v)) < 1L) {
      NA_real_
    } else {
      suppressWarnings(stats::quantile(v, p, na.rm = TRUE, names = FALSE))
    }
  }

  boot_long_df %>%
    dplyr::group_by(t, target) %>%
    dplyr::summarise(
      n_boot_total  = B,                            # planned bootstrap reps
      n_boot_ok     = sum(!is.na(val)),
      n_boot_failed = B - n_boot_ok,
      se        = safe_sd(val),
      ci_lo     = safe_q(val, alpha),
      ci_hi     = safe_q(val, 1 - alpha),
      # Distinct error messages from any failed bootstrap fits, joined
      # with " | ". NA when no fit failed. Avoids storing a per-b
      # message column (which would multiply rows or carry NULLs) while
      # still letting downstream readers diagnose what went wrong.
      boot_errors   = boot_err_str,
      .groups       = "drop"
    )
}
